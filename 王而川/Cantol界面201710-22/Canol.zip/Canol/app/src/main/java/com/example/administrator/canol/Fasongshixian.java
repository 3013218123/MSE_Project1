package com.example.administrator.canol;

import android.widget.Toast;
/**
 * Created by Administrator on 2017\10\19 0019.
 */

public class Fasongshixian {
    private String fasong;
    public Fasongshixian(String fasong){
        super();
        this.fasong=fasong;
    }
    public String getFasong(){

        return fasong;

    }
}
