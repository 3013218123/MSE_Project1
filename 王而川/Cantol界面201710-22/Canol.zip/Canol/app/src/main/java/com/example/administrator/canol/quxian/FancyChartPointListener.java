package com.example.administrator.canol.quxian;

import com.example.administrator.canol.data.Point;

public interface FancyChartPointListener {

	public void onClick(Point point);
	
}
